"""Postprocesado de esta tanda autorizada. No ejecuta ni modifica el sistema."""
import collections
from datetime import datetime
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from eval.formato import CaseResult, Grade, read_jsonl, validar_corrida
from eval.graders import calificar_corrida, cargar_casos, resumir, metricas_de
from eval.formato import Manifest, read_json
from eval.baselines.verify_b1 import verify
from eval.impacto import project, SOURCE

snapshot = json.loads((ROOT / 'reports/final_evaluation_source_snapshot.json').read_text())
changed = [p for p, sha in snapshot['files'].items() if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != sha]
if changed:
    raise SystemExit('Fuentes cambiaron durante la tanda: ' + ', '.join(changed))
dirs = []
for p in sorted((ROOT / 'eval/reports').glob('*heldout/manifest.json')):
    m = json.loads(p.read_text(encoding='utf8'))
    if m['stage'] == 'final' and datetime.fromisoformat(m['started_at'].replace('Z', '+00:00')) >= datetime.fromisoformat(snapshot['started_at']):
        if not m['finished_at']:
            raise SystemExit('Corrida todavía incompleta: ' + m['run_id'])
        dirs.append(p.parent)
if len(dirs) != 9:
    raise SystemExit(f'Se esperan nueve corridas; hay {len(dirs)}')
demo = json.loads((ROOT / 'data/runs/20260929T234658Z-7cf922c1/demo_scenarios.json').read_text(encoding='utf8'))
demo_ids = {x['transaction_id'] for x in demo}
all_cases = {x['case_id']: x for x in map(json.loads, (ROOT / 'eval/cases/heldout.jsonl').read_text(encoding='utf8').splitlines())}
exposed = sorted(k for k, c in all_cases.items() if c['expected']['transaction_id'] in demo_ids)
runs = []
groups = collections.defaultdict(list)
for d in dirs:
    man = read_json(d / 'manifest.json', Manifest)
    result = read_jsonl(d / 'results.jsonl', CaseResult)
    if len(result) != len(man.case_ids) or {r.case_id for r in result} != set(man.case_ids):
        raise SystemExit('IDs incompletos/duplicados: ' + d.name)
    if man.n_runner_error:
        raise SystemExit('Errores del runner: ' + d.name)
    if man.system == 'B1':
        audit = verify(d)
        (d / 'b1_audit.json').write_text(json.dumps(audit, indent=2), encoding='utf8')
        if not audit['passed']:
            raise SystemExit('B1 audit failed: ' + d.name)
    metrics = calificar_corrida(d)
    validar_corrida(d)
    grades = read_jsonl(d / 'grades.jsonl', Grade)
    errors = [g.model_dump(mode='json') for g in grades if g.verdict == 'grader_error']
    if errors:
        (ROOT / 'reports/final_grader_errors.json').write_text(json.dumps(errors, indent=2), encoding='utf8')
        raise SystemExit('Grader errors: ' + d.name)
    cases = cargar_casos(man)
    by_case = collections.defaultdict(list)
    for grade in grades:
        by_case[grade.case_id].append(grade)
    overlap = {}
    for label, ids in [('demo_exposed', set(exposed)), ('not_demo_exposed', set(all_cases)-set(exposed))]:
        summaries = [resumir(r, cases[r.case_id], by_case[r.case_id]) for r in result if r.case_id in ids]
        overlap[label] = [m.model_dump(mode='json') for m in metricas_de(summaries, {'demo_exposure': label}, True)]
    extractors = collections.Counter()
    messages = collections.Counter()
    for r in result:
        for t in r.trace.turns if r.trace else []:
            for s in t.spans:
                if s.name == 'nlu.understand':
                    extractors[s.output.get('extractor', 'missing')] += 1
        for t in r.turns:
            if t.response:
                messages.update(m.source for m in t.response.messages)
    record = {'run_id': d.name, 'system': man.system, 'llm': man.llm, 'run_number': man.run_number,
              'git_commit': man.git_commit, 'git_dirty': man.git_dirty, 'versions': man.versions.model_dump(),
              'n_cases': len(result), 'cost_usd': sum(r.cost_usd for r in result),
              'tokens_in': sum(r.tokens_in for r in result), 'tokens_out': sum(r.tokens_out for r in result),
              'n_max_turns': man.n_max_turns, 'n_runner_error': man.n_runner_error,
              'extractors': dict(extractors), 'message_sources': dict(messages),
              'metrics': [m.model_dump(mode='json') for m in metrics.metrics], 'demo_exposure': overlap}
    runs.append(record)
    groups[(man.system, man.llm)].append(record)

def aggregate(records):
    values = collections.defaultdict(list)
    for r in records:
        for m in r['metrics']:
            if m['value'] is not None:
                values[(m['name'], json.dumps(m['slice'], sort_keys=True))].append(m['value'])
    return [{'metric': name, 'slice': json.loads(sl), 'mean': statistics.mean(vals), 'min': min(vals), 'max': max(vals), 'n_runs': len(vals)}
            for (name, sl), vals in values.items()]

summary = {'source_snapshot': 'reports/final_evaluation_source_snapshot.json', 'heldout_sha256': hashlib.sha256((ROOT/'eval/cases/heldout.jsonl').read_bytes()).hexdigest(),
           'grader_version': '1.1.0', 'exposed_case_ids': exposed, 'runs': runs,
           'groups': [{'system': k[0], 'llm': k[1], 'run_ids': [r['run_id'] for r in rs], 'aggregate': aggregate(rs)} for k, rs in groups.items()],
           'total_estimated_cost_usd': sum(r['cost_usd'] for r in runs),
           'cost_note': 'Estimación de las trazas con los precios configurados en backend; no factura. Prueba de conectividad adicional: USD 0.00024525.'}
for records in groups.values():
    if sorted(r['run_number'] for r in records) != [1,2,3]:
        raise SystemExit('No hay tres repeticiones distintas por configuración')
out = ROOT/'eval/reports/final_summary_datos.json'
out.write_text(json.dumps(summary, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf8')
s = groups[('S','with_gemini')]
rates = [next(m['value'] for m in r['metrics'] if m['name']=='safe_auto_resolution' and not m['slice']) for r in s]
impact = project(json.loads(SOURCE.read_text(encoding='utf8')), statistics.mean(rates), min(rates), max(rates))
impact['rate_source'] = [r['run_id'] for r in s]
impact['source'] = {'path': str(SOURCE.relative_to(ROOT)), 'sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest()}
(ROOT/'eval/reports/impacto_final.json').write_text(json.dumps(impact, indent=2, ensure_ascii=False, allow_nan=False),encoding='utf8')
print(json.dumps({'runs':len(runs),'cost':summary['total_estimated_cost_usd'],'rates':rates,'exposed':exposed}))
